Please Read this before loading on device

@FreeApple Anthony Cornell

Welcome to the BlueBird-HD  4.2.1 useroverlay

On 4.2.1 Apple has changed the directory for the lockbackgroundPortrait.png so I have yet to find where to call out this image from the html I have set this up to place 
your images ine the "Lock" folder. Just name your 640X960 image named LockBackground.png 
