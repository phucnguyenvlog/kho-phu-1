Documentation for Aelon & Aeternum Compatibility
===================================


How to implement :
-----------------

  > Copy the IconMask@2x.png & IconMask@3x.png files present in the folder.
  > Now go to Library/PreferenceBundles/Aeternum.bundle/
  > Paste the two images over there (overwrite all) and you are done !
  > Enjoy !