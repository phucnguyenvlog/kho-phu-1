var this_weekday_name_array = new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday")
var this_month_name_array = new Array("January","February","March","April","May","June","July","August","September","October","November","December") //predefine month names
    
var this_date_timestamp = new Date()    

var this_weekday = this_date_timestamp.getDay()    
var this_date = this_date_timestamp.getDate()    
var this_month = this_date_timestamp.getMonth()    
var this_year = this_date_timestamp.getYear()    

if (this_year < 1000)
    this_year+= 1900;
if (this_year==101)
    this_year=2001;        

var this_date_string = this_weekday_name_array[this_weekday] + " " + this_date + " " + this_month_name_array[this_month]; //concat long date string

// true for 24hr time
var tfHour = false;

function init ( )
{
  timeDisplay = document.createTextNode ( "" );
  document.getElementById("clock").appendChild ( timeDisplay );
}

function updateClock ( )
{
  var currentTime = new Date ( );

  var currentHours = currentTime.getHours ( );
  var currentMinutes = currentTime.getMinutes ( );
  var currentSeconds = currentTime.getSeconds ( );

  // Pad the minutes and seconds with leading zeros, if required
  currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
  currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;

  // If 24 Hour clock pad hours with leading 0 - if 12hr get AM-PM value
  if (tfHour) {
    currentHours = (currentHours < 10 ? "0" : "") + currentHours;
  }
  else {

  // Convert the hours component to 12-hour format if needed
  currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;

  // Convert an hours component of "0" to "12"
  currentHours = ( currentHours == 0 ) ? 12 : currentHours;

  }
  // Compose the string for display
  var currentTimeString = currentHours + ":" + currentMinutes;

  // Update the time display
  document.getElementById("clock").firstChild.nodeValue = currentTimeString;
}

function init2 ( )
{
  timeDisplay = document.createTextNode ( "" );
  document.getElementById("ampm").appendChild ( timeDisplay );
}

function amPm ( )
{
  var timeOfDay = "";
  
  if (!tfHour) {
    var currentTime = new Date ( );

    var currentHours = currentTime.getHours ( );

    // Choose either "AM" or "PM" as appropriate
    timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";
  }

  // Update the time display
  document.getElementById("ampm").firstChild.nodeValue = timeOfDay;
}

function init3 ( )
{
  timeDisplay = document.createTextNode ( "" );
  document.getElementById("calendar").appendChild ( timeDisplay );
}

function calendarDate ( )
{
  var this_weekday_name_array = new Array("Sun","Mon","Tues","Wed","Thur","Fri","Sat")
  var this_month_name_array = new Array("Jan","Feb","Mar","Apr","May","June","July","Aug","Sep","Oct","Nov","Dec") //predefine month names
    
  var this_date_timestamp = new Date()    

  var this_weekday = this_date_timestamp.getDay()    
  var this_date = this_date_timestamp.getDate()    
  var this_month = this_date_timestamp.getMonth()    
  
document.getElementById("calendar").firstChild.nodeValue = this_weekday_name_array[this_weekday] + "," + " " + this_month_name_array[this_month] + " " + this_date //concat long date string
}
